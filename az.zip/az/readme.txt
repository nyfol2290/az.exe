

 █████╗ ███████╗   ███████╗██╗  ██╗███████╗
██╔══██╗╚══███╔╝   ██╔════╝╚██╗██╔╝██╔════╝
███████║  ███╔╝    █████╗   ╚███╔╝ █████╗  
██╔══██║ ███╔╝     ██╔══╝   ██╔██╗ ██╔══╝  
██║  ██║███████╗██╗███████╗██╔╝ ██╗███████╗
╚═╝  ╚═╝╚══════╝╚═╝╚══════╝╚═╝  ╚═╝╚══════╝
                                           
                                           
Malware name: az.exe
By: Nyfol2290 (only)
Malware type: Destroy
Description: This is a only GDI malware, not open the programs and moving windows, this is a Win32.Kill.Trojan